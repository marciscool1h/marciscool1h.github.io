## plugin.video.f1tv

### About

-Watch F1 TV (live) content

### Features

-Unofficial 3rd Party F1 TV plugin for Kodi

### Required

-Subscription to F1 TV (not free)

-Kodi 19 or higher with Widevine Support (free)

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-peak3d for Inputstream Adaptive

-Team Kodi for Kodi